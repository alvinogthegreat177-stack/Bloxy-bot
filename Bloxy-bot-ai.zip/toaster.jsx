import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast";

export function Toaster() {
  const { toasts, dismiss } = useToast();
  const [expanded, setExpanded] = useState({});

  return (
    <ToastProvider>
      {toasts.map(function ({ id, title, description, action, ...props }) {
        const isLong = description && String(description).length > 120;
        const isExpanded = expanded[id];
        return (
          <Toast key={id} {...props}>
            <div className="grid gap-1">
              {title && <ToastTitle>{title}</ToastTitle>}
              {description && (
                <ToastDescription className={isLong && !isExpanded ? "line-clamp-2" : ""}>
                  {description}
                </ToastDescription>
              )}
              {isLong && (
                <button
                  onClick={() => setExpanded((prev) => ({ ...prev, [id]: !prev[id] }))}
                  className="text-xs text-orange-400 hover:text-orange-300 mt-0.5"
                >
                  {isExpanded ? "Show less" : "Show more"}
                </button>
              )}
            </div>
            {action}
            <ToastClose onClick={() => dismiss(id)} />
          </Toast>
        );
      })}
      <ToastViewport />
    </ToastProvider>
  );
}